export default {
    SERVER: {
        PORT: 5001,
    },
    DATABASE: {
        MONGO_URI:
        'mongodb+srv://amitjoshi:Dealing%40123@cluster0.vjxa6ad.mongodb.net/test',
    MONGO_DB_NAME: 'API',
    }
}