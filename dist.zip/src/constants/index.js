export { default as ENV } from './envVariable';
